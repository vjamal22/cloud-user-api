import json

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "http://localhost:5173",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "OPTIONS,POST",
}

def lambda_handler(event, context):

    body = json.loads(event.get("body", "{}"))

    user_id = body.get("user_id")
    profile_data = body.get("profile_data")

    if not user_id or not profile_data:
        return {
            "statusCode": 400,
            "headers": CORS_HEADERS,
            "body": json.dumps({
                "message": "Missing user_id or profile_data"
            })
        }

    goal = profile_data.get("goal", "").lower()
    activity_level = profile_data.get("activity_level", "").lower()

    if goal == "weight loss":
        workout_plan = [
            "Day 1: HIIT Cardio",
            "Day 2: Full Body Circuit",
            "Day 3: Walking and Mobility",
            "Day 4: HIIT Cardio",
            "Day 5: Strength Training"
        ]

        meal_plan = [
            "Breakfast: Greek yogurt and berries",
            "Lunch: Grilled chicken salad",
            "Dinner: Salmon and vegetables"
        ]

    elif goal == "muscle gain":
        workout_plan = [
            "Day 1: Chest and Triceps",
            "Day 2: Back and Biceps",
            "Day 3: Legs",
            "Day 4: Shoulders",
            "Day 5: Full Body Strength"
        ]

        meal_plan = [
            "Breakfast: Eggs and oats",
            "Lunch: Chicken, rice, and vegetables",
            "Dinner: Steak and sweet potatoes"
        ]

    else:
        workout_plan = [
            "Day 1: Full Body Workout",
            "Day 2: Cardio",
            "Day 3: Rest",
            "Day 4: Upper Body",
            "Day 5: Lower Body"
        ]

        meal_plan = [
            "Breakfast: Oatmeal and fruit",
            "Lunch: Grilled chicken salad",
            "Dinner: Salmon with vegetables"
        ]

    if activity_level == "high":
        workout_plan.append("Bonus Day: Endurance Training")

    return {
        "statusCode": 200,
        "headers": CORS_HEADERS,
        "body": json.dumps({
            "workout_plan": workout_plan,
            "meal_plan": meal_plan
        })
    }